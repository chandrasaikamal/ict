//make the required changes to this class so that InvalidPackageIdException is of type exception.

import java.lang.Exception;

public class InvalidPackageIdException extends Exception {

//fill your code here
	
	InvalidPackageIdException(){
		System.out.println("Invalid Package Id");
	}
}
	