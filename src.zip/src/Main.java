import java.util.*;

public class Main {

	public static void main(String[] args) throws Exception {

		//fill your code here
		TravelAgency ta = new TravelAgency();
		List<Package> l = ta.generatePackageCost("VarshTourPackageDetails.txt");
		List<Package> l1 = ta.findPackagesWithMinimulNumberOfDays();
		for(Package p : l){
			System.out.println(p.getPackageId()+" "+p.getSourcePlace()+" "+p.getDestinationPlace()+" "+p.getBasicFare()+" "+p.getNoOfDays()+" "+p.getPackageCost());
		}

	}

}
