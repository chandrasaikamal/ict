
import java.io.*;
import java.sql.*;
import java.util.*;

public class DBHandler {
	
	private static Connection conn = null;
	private static Properties props = new Properties();	

	public Connection establishConnection() throws ClassNotFoundException, SQLException{
    
    	// Fill you code Here
	try{
		FileInputStream fis = null;
		fis = new FileInputStream("db.properties");
		props.load(fis);
		Class.forName(props.getProperty("db.classname"));
		conn = DriverManager.getConnection(props.getProperty("db.url"), props.getProperty("db.username"), props.getProperty("db.password"));
	}
   	catch(IOException e){
		e.printStackTrace();
	}
	return conn;
	}
}