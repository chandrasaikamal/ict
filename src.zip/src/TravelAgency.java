
import java.util.List;
import java.sql.*;
import java.io.*;
import java.util.*;

public class TravelAgency {
    
    //write the required business logic methods as expected in the question description
	
	public List<Package> generatePackageCost(String filePath) {
		
		// Fill you code Here
		List<Package> l = new ArrayList<Package>();
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		TravelAgency ta = new TravelAgency();
		String s = "";
		while( (s = br.readLine() ) != null ){
			String x[] = s.split(",");
			try{
				if(ta.validate(x[0]){
					Package p = new Package();
					p.setPackageId(x[0]);
					p.setSourcePlace(x[1]);
					p.setDestinationPlace(x[2]);
					p.setBasicFare(Double.parseDouble(x[3]));
					p.setNoOfDays(Integer.parseInt(x[4]));
					p.calculatePackageCost();
					l.add(p);
				}
			}
			catch(InvalidPackageIdException e){

			}
		}
		return l;
	}
	
	public boolean validate(String packageId) throws InvalidPackageIdException {
		
    	// Fill you code Here
		
		if(packageId.lenght() == 7 && packageId.charAt(3) == '/')
			return true;
		else
			throw new InvalidPackageIdException();
	}
	
	
	public List<Package> findPackagesWithMinimumNumberOfDays() {
		
		// Fill you code Here
		List<Package> l = new ArrayList<Package>();
		DBHandler db = new DBHandler();
		Connection conn = db.establishConnection();
		String s = "select * from package_details where no_of_days = (select min(no_of_days) from package_details)";
		PreparedStatement ps = conn.prepareStatement(s);
		ResultSet rs = ps.executeQuery();
		while(rs.next()){
			Package p = new Package();
			p.setPackageId(rs.getString(1));
			p.setSourcePlace(rs.getString(2));
			p.setDestinationPlace(rs.getString(3));
			p.setNoOfDays(rs.getInt(4));
			p.setPackageCost(rs.getDouble(5));
			l.add(p);
		}
		return l;
	}
}
